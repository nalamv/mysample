package com.fc.spring.demo.service;

import com.fc.spring.demo.modal.Employee;
import com.fc.spring.demo.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;

@Service
public class EmployeeServiceImplementation implements EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    @Override
    public ArrayList<Employee> findAllEmployee() {
        System.out.println("printing all employee data");
        return (ArrayList<Employee>) employeeRepository.findAll();
    }

    @Override
    public Employee findAllEmployeeByID(int id) {
        Optional<Employee> opt = employeeRepository.findById(id);
        return opt.orElse(null);
    }

    @Override
    public Employee findEmployeeByIDandName(int id, String name) {
        return employeeRepository.findByIdAndName(id,name);
    }

    @Override
    public Employee addEmployeePayload(Employee newemployee) {
        Employee newEmp=new Employee(newemployee.getName(), newemployee.getGender(), newemployee.getSalary(), newemployee.getCity());
        return employeeRepository.save(newEmp);

    }

    @Override
    public void addEmployee() {
        ArrayList<Employee> employees = new ArrayList<Employee>();
        employees.add(new Employee(11, "Nithya", "F", 20000, "Hyderabad"));
        employees.add(new Employee(12, "karthik", "M", 25000, "Hyderabad"));
        for (Employee each : employees)
            employeeRepository.save(each);
    }

    @Override
    public void deleteById(int id) {
        employeeRepository.deleteById(id);
    }


}
