package com.fc.spring.demo.service;

import com.fc.spring.demo.modal.Employee;

import java.util.ArrayList;

public interface EmployeeService {

    ArrayList<Employee> findAllEmployee();
    Employee findAllEmployeeByID(int id);

    Employee addEmployeePayload(Employee newemployee);

    void addEmployee();
    void deleteById(int id);
    Employee findEmployeeByIDandName(int id, String name);
}
