package com.fc.spring.demo.controller;

import com.fc.spring.demo.modal.Employee;
import com.fc.spring.demo.service.EmployeeServiceImplementation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@RestController
public class EmployeeController {

    @Autowired
    EmployeeServiceImplementation employeeServiceImplementation;

    @PostMapping("/add")
    public void addEmployee() {
        employeeServiceImplementation.addEmployee();
    }

    @GetMapping("/findAll")
    public ArrayList<Employee> getAllEmployee() {
        return employeeServiceImplementation.findAllEmployee();
    }

    @GetMapping("/findById/{id}")
    public Employee getEmployeeById(@PathVariable("id") int id) {
        System.out.println("Employee Id:"+id);
        return employeeServiceImplementation.findAllEmployeeByID(id);
    }

    @GetMapping("/findById/{id}/{name}")
    public Employee getEmployeeById(@PathVariable("id") int id, @PathVariable("name") String name) {
        System.out.println("Employee Id:"+id);
        return employeeServiceImplementation.findEmployeeByIDandName(id,name);
    }

    @DeleteMapping("/deleteById/{id}")
    public void deleteEmployeeById(@PathVariable("id") int id) {
        employeeServiceImplementation.deleteById(id);
    }

    @PostMapping("/addEmployee")
    public ResponseEntity<Map<String, Object>> addEmployee(@RequestBody Employee employeeDetails) {
       Employee postedRecord= employeeServiceImplementation.addEmployeePayload(employeeDetails);
        Map<String, Object> response=new HashMap<>();
        response.put("message","Employee record created successfully");
        response.put("employee",postedRecord);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }



}
