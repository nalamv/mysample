package com.fc.spring.demo.modal;

import jakarta.persistence.*;

@Entity
@Table(name ="Employee")
public class Employee {


    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "Id")
    private int id;

    @Column(name = "name")
    private String name;

    @Column(name = "Gender")
    private String gender;

    @Column(name = "salary")
    private long salary;

    @Column(name = "city")
    private String city;

    public Employee() {
        super();
    }

    public Employee(int id, String name, String gender, long salary, String city) {
        super();
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.salary = salary;
        this.city = city;
    }

    public Employee(String name, String gender, long salary, String city) {
        super();
        this.name = name;
        this.gender = gender;
        this.salary = salary;
        this.city = city;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public long getSalary() {
        return salary;
    }

    public void setSalary(long salary) {
        this.salary = salary;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

}
